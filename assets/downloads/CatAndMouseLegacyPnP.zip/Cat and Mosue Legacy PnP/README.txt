*Cat and Mouse: Legacy*
Print and Play Version 0.9
by Mirek Stolee
01/10/2022

To assemble:

2. Cards
Print out the card sheet on a double-sided printer using letter-size paper. Card stock is best.
Cut the cards out by cutting straight down the trim lines on the edges of the paper.

1. Overlay
This game can be played on the original Cat and Mouse overlay, but you may prefer
to print one just for this game. A slightly transparent paper like vellum works great.
You may also draw your own overlay on such paper. Each square is 1" x 1", and the total
dimensions are 11" x 14". Depending on what kind of paper / TV you use, the overlay
may or may not stay attached to the screen on its own. Scotch tape works well, but
be careful to not damage your screen.

3. Sticker sheet
Print out the sticker sheet and cut each item out separately. You should have 9 square
stickers with images on them, and rule stickers A-H. You can tape these on the overlay
when the game calls for it, or you may turn them into stickers with a sticker machine.

4. Envelopes
//TODO
